export const INPUT_FOUCS = 'header/input_focus';
export const INPUT_BLUR = 'header/input_blur';
export const CHANGE_ITEM = 'header/change_item';
export const MOUSE_ENTER ='header/mouse_enter';
export const MOUSE_LEAVE = 'header/mouse_leave';
export const CHANGE_PAGE = 'header/change_page';