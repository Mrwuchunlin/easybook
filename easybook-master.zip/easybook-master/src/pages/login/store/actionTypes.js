export const GET_LOGIN_DATA = 'login/GET_LOGIN_DATA';
export const GET_LOGOUT_DATA = 'login/GET_LOGOUT_DATA';