export const CHANGE_HOME_DATA = 'home/CHANGE_HOME_DATA';
export const ADD_MORE_LIST = 'home/ADD_MORE_LIST';
export const CHANGE_SCROLL_TOP = 'home/CHANGE_SCROLL_TOP';